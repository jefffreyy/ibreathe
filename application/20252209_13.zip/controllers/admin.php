<?php defined('BASEPATH') or exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Worksheet\SheetView;

ob_start();
class admin extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('session');
        $this->load->model('user_model');
        $this->load->library('upload');
    }
    public function do_upload()
    {
        $config['upload_path']   = './assets_systems/';
        $config['allowed_types'] = 'jpg';
        $config['max_size']      = 2048; // 2MB
        $config['overwrite']     = TRUE;
        // $config['encrypt_name']  = TRUE;
        $config['file_name']  = 'uploaded_image';
        $this->upload->initialize($config);

        $data = array();

        if (!$this->upload->do_upload('userfile')) {
            $data['error'] = $this->upload->display_errors();
            echo $data['error'];
        } else {
            $data['upload_data'] = $this->upload->data();
            echo "Attachment added successfully!";
        }

        //  redirect('admin/dashboard');
    }
     public function editseats()
    {
        $this->load->model('user_model');
   
        $current_seats = $this->user_model->get_total_seats();
   

        $data['current_seats'] = $current_seats;

        $this->load->view('admin_editseats', $data);
    }
    public function editseats_command()
    {
        $this->load->model('user_model');
       
        $current_seats = $this->user_model->get_total_seats();

                    
                $new_seat_count = (int) $this->input->post('seat_count');
       
                if ($new_seat_count > $current_seats) {
          
                    $this->user_model->add_seats($current_seats + 1, $new_seat_count);
                } else if ($new_seat_count < $current_seats) {
              
                    $this->user_model->remove_seats($new_seat_count + 1, $current_seats);
                }


        redirect('admin/editseats');
    }
    // $this->load->view('masteradmin_summary', $data);

    public function summaryreport()
    {
        $this->load->model('user_model');

        $filter_type = $this->input->get('filter_type') ?? 'daily';

        // Get filter_date according to filter_type's input name
        switch ($filter_type) {
            case 'daily':
                $filter_date = $this->input->get('filter_date') ?? date('Y-m-d');
                break;
            case 'weekly':
                $filter_date = $this->input->get('filter_weekly') ?? date('Y-\WW');
                break;
            case 'monthly':
                $filter_date = $this->input->get('filter_monthly') ?? date('Y-m');
                break;
            default:
                $filter_date = date('Y-m-d');
                break;
        }

        switch ($filter_type) {
            case 'daily':
                $start_date = $filter_date;
                $end_date = $filter_date;
                break;

            case 'weekly':
                if (preg_match('/^(\d{4})-W(\d{1,2})$/', $filter_date, $matches)) {
                    $year = (int) $matches[1];
                    $week = (int) $matches[2];

                    $date = new DateTime();
                    $date->setISODate($year, $week);
                    $start_date = $date->format('Y-m-d');
                    $end_date = $date->modify('+6 days')->format('Y-m-d');
                } else {
                    $start_date = $end_date = date('Y-m-d');
                }
                break;

            case 'monthly':
                $start_date = $filter_date . '-01';
                $end_date = date("Y-m-t", strtotime($start_date));
                break;

            default:
                $start_date = $end_date = date('Y-m-d');
                break;
        }

        $selected_user = $this->input->get('user_id');

        $data['filter_type'] = $filter_type;
        $data['filter_date'] = $filter_date;
        $data['selected_user'] = $selected_user;
$data['top_users'] = $this->user_model->get_top_users_this_month();
        $data['users'] = $this->user_model->get_all_users();
        $data['summary'] = $this->user_model->get_summarya($start_date, $end_date, $selected_user);

        $this->load->view('masteradmin_summary', $data);
    }
    public function adminlogin()
    {
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $username = $this->input->post('user_id');
            $password = $this->input->post('password');

            if ($username === 'admin' && $password === 'admin') {
                $this->session->set_userdata([
                    'master_admin_logged_in' => true,
                    'admin_username' => $username
                ]);
                redirect('masteradmin/dashboard');
                return;
            }

            $this->load->model('user_model');
            $librarian = $this->user_model->get_librarian_by_credentials($username, $password);

            if ($librarian) {
                $this->session->set_userdata([
                    'admin_logged_in' => true,
                    'admin_username' => $librarian->username
                ]);
                redirect('admin/dashboard');
            } else {
                $data['error'] = 'Invalid username or password';
                $this->load->view('adminlogin.php', $data);
            }
        } else {
            $this->load->view('adminlogin.php');
        }
    }




    public function dashboard()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/adminlogin');
        }

        $this->load->model('user_model');

        // Check if form was submitted via GET
        $selected_date = $this->input->get('day');
        $selected_timeslot = $this->input->get('timeslot');

        if (!empty($selected_date) && !empty($selected_timeslot)) {
            // Use selected values from form
            $future_date = date('Y-m-d H:i:s', strtotime($selected_date));
            $timeslot = $selected_timeslot;
            $timename = $this->getTimeNameFromSlot($timeslot);
        } else {
            // Default to current datetime
            $current_date = date('Y-m-d H:i:s');
            $future_date = $current_date;
            $timeslot = $this->getTimeSlot($future_date);
            $timename = $this->getTimeName($future_date);
        }

        $slot_status_db = $this->user_model->get_all_slots($future_date, $timeslot);

        $slot_display = [];

        foreach ($slot_status_db as $row) {
            if ($timeslot != 0) {
                switch ($row->final_status) {
                    case 'Open':
                        $slot_display[] = "available";
                        break;
                    case 'Closed':
                        $slot_display[] = "closed";
                        break;
                    case 'Occupied':
                        $slot_display[] = "occupied";
                        break;
                    case 'Cancelled':
                        $slot_display[] = "available";
                        break;
                    default:
                        $slot_display[] = "not-available";
                }
            } else {
                $slot_display[] = "not-available";
            }
        }

        $data['current_date'] = $future_date;
        $data['time_slot'] = $timeslot;
        $data['time_name'] = $timename;
        $data['slot_display'] = $slot_display;

        $this->load->view('admin-monitoring', $data);
    }
function opening_hours(){
    $this->load->model('user_model');

    $hours = $this->user_model->get_opening_hours();
    $data['start_time'] = $hours ? $hours->start_time : '';
    $data['end_time'] = $hours ? $hours->end_time : '';
    $data['success'] = '';
    $data['error'] = '';



         $this->load->view('admin_openinghours', $data);
}
public function update_hours()
{
    $this->load->model('user_model');

    $start_time = $this->input->post('start_time', TRUE);
    $end_time   = $this->input->post('end_time', TRUE);

    // Basic validation
    if (empty($start_time) || empty($end_time)) {
        $data['error'] = 'Start and End time are required.';
    } else {
        if ($this->user_model->update_opening_hours($start_time, $end_time)) {
            $data['success'] = 'Opening hours updated successfully.';
        } else {
            $data['error'] = 'Failed to update opening hours.';
        }
    }

    // Reload the current values (or what was just submitted)
    $data['start_time'] = $start_time;
    $data['end_time'] = $end_time;

    $this->load->view('admin_openinghours', $data);
}
    function getTimeSlot(string $dateTimeStr): int
    {
        $dateTime = new DateTime($dateTimeStr);

        $timeSlots = [
            1 => ['07:00', '08:30'],
            2 => ['08:30', '10:00'],
            3 => ['10:00', '11:30'],
            4 => ['11:30', '13:00'],
            5 => ['13:00', '14:30'],
            6 => ['14:30', '16:00'],
            7 => ['16:00', '17:00']
        ];

        $time = $dateTime->format('H:i');

        foreach ($timeSlots as $slot => [$start, $end]) {
            if ($time >= $start && $time < $end) {
                return $slot;
            }
        }

        return 0; // Return 0 if the time does not fall in any slot
    }

    function getTimeName(string $dateTimeStr): String
    {
        $dateTime = new DateTime($dateTimeStr);

        $timeSlots = [
            1 => ['07:00', '08:30', '07:00 - 08:30 AM'],
            2 => ['08:30', '10:00', '08:30 - 10:00 AM'],
            3 => ['10:00', '11:30', '10:00 - 11:30 AM'],
            4 => ['11:30', '13:00', '11:30 - 01:00 PM'],
            5 => ['13:00', '14:30', '01:00 - 02:30 PM'],
            6 => ['14:30', '16:00', '02:30 - 04:00 PM'],
            7 => ['16:00', '17:00', '04:00 - 05:00 PM']
        ];

        $time = $dateTime->format('H:i');

        foreach ($timeSlots as $slot => [$start, $end, $dur]) {
            if ($time >= $start && $time < $end) {
                return $dur;
            }
        }

        return 'Outside Library Hours'; // Return 0 if the time does not fall in any slot
    }

    public function getTimeNameFromSlot($slot_id)
    {
        $timeSlots = [
            1 => ['07:00', '08:30', '07:00 - 08:30 AM'],
            2 => ['08:30', '10:00', '08:30 - 10:00 AM'],
            3 => ['10:00', '11:30', '10:00 - 11:30 AM'],
            4 => ['11:30', '13:00', '11:30 - 01:00 PM'],
            5 => ['13:00', '14:30', '01:00 - 02:30 PM'],
            6 => ['14:30', '16:00', '02:30 - 04:00 PM'],
            7 => ['16:00', '17:00', '04:00 - 05:00 PM']
        ];

        return isset($timeSlots[$slot_id]) ? $timeSlots[$slot_id][2] : 'Unknown';
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('admin/adminlogin');
    }



    //From here on, now all about the new updates.

    public function reservation_request()
    {
        $this->load->model('user_model');
        $data['requests'] = $this->user_model->get_all_professor_requests();
        $this->load->view('admin_reservation_request.php', $data);
    }

    public function process_request($id)
    {
        $this->load->model('user_model');
        $data['request'] = $this->user_model->get_request_by_id($id);

        if (!$data['request']) {
            show_404(); // Optional: show 404 if not found
        }

        // Get slot name from ID
        $slot_id = $data['request']['time_slot'];
        $data['request']['slot_name'] = $this->user_model->get_slot_name_by_id($slot_id);

        $this->load->view('admin_process_reservation_request', $data);
    }

    public function process_request_ongoing($id)
    {
        $this->load->model('user_model');
        $data['request'] = $this->user_model->get_request_by_id_ongoing($id);

        if (!$data['request']) {
            show_404(); // Optional: show 404 if not found
        }

        // Get slot name from ID
        $slot_id = $data['request']['time_slot'];
        $data['request']['slot_name'] = $this->user_model->get_slot_name_by_id($slot_id);

        $this->load->view('admin_ongoing_process_request.php', $data);
    }


    public function ongoing_request()
    {
        $this->load->model('user_model');
        $data['ongoing_requests'] = $this->user_model->get_all_professor_ongoing();
        $this->load->view('admin_ongoing_reservation_request', $data);
    }


    public function reject_request($id)
    {
        $this->load->model('user_model');
        $request = $this->user_model->get_request_by_id($id);

        if (!$request) {
            show_404();
        }

        $reason = $this->input->post('rejection_reason');
        $request['status'] = 'REJECTED';
        $request['seat_assigned'] = ''; // default if needed
        $request['rejection_reason'] = $reason; // add the reason

        $this->user_model->insert_rejected_request($request);
        $this->user_model->delete_request_by_id($id);

        redirect('admin/reservation_request');
    }

    public function selectseats($id)
    {
        $this->load->model('user_model');
        $data['request'] = $this->user_model->get_request_by_id($id);

        //REALTIME FOR UPDATES
        $current_date = date('Y-m-d H:i:s');
        $future_date = date('Y-m-d H:i:s', strtotime($current_date . ' 0 hours'));

        $selected_date = $data['request']['date'];
        $slot_id = $data['request']['time_slot'];
        $num_of_seats = $data['request']['num_of_seats'];
        $slot_name = $this->user_model->get_slot_name_by_id($slot_id);

        $slot_status_db = $this->user_model->get_all_slots($selected_date, $slot_id);

        $slot_display = [];

        foreach ($slot_status_db as $row) {
            if ($slot_id != 0) {
                if ($row->final_status == "Open") {
                    $slot_display[] = "available";
                } elseif ($row->final_status == "Closed") {
                    $slot_display[] = "closed";
                } elseif ($row->final_status == "Occupied") {
                    $slot_display[] = "occupied";
                } elseif ($row->final_status == "Cancelled") {
                    $slot_display[] = "available";
                } elseif ($row->final_status == "not-available") {
                    $slot_display[] = "not-available";
                } else {
                    $slot_display[] = "not-available";
                }
            } else {
                $slot_display[] = "not-available";
            }
        }

        if (!$data['request']) {
            show_404(); // Optional: show 404 if not found
        }

        //realtime update
        $data['current_date'] = $future_date;

        //sets the color of seats based on availability
        $data['slot_display'] = $slot_display;

        //data based on request
        $data['selected_date'] = $selected_date;
        $data['time_slot'] = $slot_name;
        $data['num_of_seats'] = $num_of_seats;

        $this->load->view('class_select_seats.php', $data);
    }


    public function confirm_reservation($id)
    {
        $this->load->model('user_model');

        $seat_assigned = $this->input->post('seat_assigned'); // e.g., "1,3,5"
        $seats = explode(',', $seat_assigned);

        $request = $this->user_model->get_professor_request($id);

        if ($request) {
            // 1. Insert into tbl_library_assign per seat
            foreach ($seats as $seat_id) {
                $assign_data = [
                    'student_id'    => $request->prof_id,
                    'seat_id'       => trim($seat_id),
                    'slot_id'       => $request->time_slot,
                    'date_reserve'  => $request->date,
                    'created_date'  => date('Y-m-d H:i:s'),
                    'status'        => 'Closed',
                    'is_assigned'   => 1
                ];

                $this->user_model->insert_library_assign($assign_data);
            }

            // 2. Insert to tbl_library_professor_ongoing
            $data = [
                'prof_name'     => $request->prof_name,
                'prof_id'       => $request->prof_id,
                'date'          => $request->date,
                'time_slot'     => $request->time_slot,
                'num_of_seats'  => $request->num_of_seats,
                'prof_note'     => $request->prof_note,
                'seat_assigned' => $seat_assigned,
                'status'        => 'APPROVED'
            ];

            $this->user_model->insert_professor_ongoing($data);

            // 3. Delete from tbl_library_professor_request
            $this->user_model->delete_professor_request($id);

            redirect('admin/reservation_request');
        } else {
            show_error('Invalid request ID');
        }
    }

    public function terminated_reservation($id)
    {
        $this->load->model('user_model');

        // Get the reservation request
        $request = $this->user_model->get_professor_ongoing($id);

        if (!$request) {
            show_error('Invalid ongoing request ID.');
            return;
        }

        $prof_id = $request->prof_id;
        $seat_assigned = explode(',', $request->seat_assigned); // break down assigned seats
        $date_reserve = $request->date;

        // Loop through each seat and process
        foreach ($seat_assigned as $seat_id) {
            $assign = $this->user_model->get_assign_data($prof_id, trim($seat_id), $date_reserve);

            if ($assign && $assign->is_assigned == 1) {
                // Move to tbl_library_assign_deleted
                $this->user_model->archive_assign_data($assign);
            }
        }

        // Move reservation to terminated table
        $request->status = 'TERMINATED';
        $this->user_model->archive_professor_ongoing($request);

        // Delete original ongoing record
        $this->user_model->delete_professor_ongoing($id);

        redirect('admin/ongoing_request');
    }

    function password_reset()
    {
        $this->load->view("admin_password_reset.php");
    }

    function verify_student_id()
    {
        $student_id = $this->input->post('student_id');
        $this->load->model('user_model');

        if ($this->user_model->check_student_id($student_id)) {
            // Save to session
            $this->session->set_userdata('reset_student_id', $student_id);
            redirect('admin/new_password');
        } else {
            echo "<script>alert('Account does not exist.'); window.location.href='" . site_url('admin/password_reset') . "';</script>";
        }
    }

    function new_password()
    {
        if (!$this->session->userdata('reset_student_id')) {
            redirect('admin/password_reset');
        }
        $this->load->view("admin_new_password.php");
    }

    function update_credentials()
    {
        $this->load->model('user_model');
        $student_id = $this->session->userdata('reset_student_id');

        if (!$student_id) {
            redirect('admin/password_reset');
        }

        $password = $this->input->post('newPassword');
        $confirmPassword = $this->input->post('confirmPassword');
        $secquestion = $this->input->post('securityQuestion');
        $answer = $this->input->post('securityAnswer');
        $confirmAnswer = $this->input->post('confirmSecurityAnswer');


        if ($password != $confirmPassword || $answer != $confirmAnswer) {
            echo "<script>alert('Passwords or answers do not match.'); window.history.back();</script>";
            return;
        }

        $updated = $this->user_model->update_credentials($student_id, $password, $secquestion, $answer);

        if ($updated) {
            $this->session->unset_userdata('reset_student_id');
            redirect('admin/changed_success');
        } else {
            echo "<script>alert('Update failed.'); window.history.back();</script>";
        }
    }

    function changed_success()
    {
        $this->load->view("changed_password_success.php");
    }

    function admin_settings()
    {
        $this->load->view("admin_settings.php");
    }

    public function qr_settings()
    {
        $this->load->model('user_model');
        $data['qr_restriction'] = $this->user_model->get_qr_restriction();
        $this->load->view('admin_settings', $data);
    }



    public function update_qr_setting()
    {
        $this->load->model('user_model');

        $qr_restriction = $this->input->post('qr_restriction') ? 1 : 0;

        $this->user_model->update_qr_restriction($qr_restriction);
        redirect('admin/qr_settings');
    }

    public function disable_seat($seat_id = null)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/adminlogin'); // Redirect to login if not logged in
        }

        if ($seat_id === null) {
            show_error('Seat ID is required.', 400);
        }

        date_default_timezone_set('Asia/Manila');
        $currentDate = date('Y-m-d H:i:s');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $seat_id = $this->input->post('seat_id'); // Get from form
            $date_disabled = $this->input->post('date_disabled');

            if (!$date_disabled) {
                show_error('Date Disabled is required.', 400);
            }

            $this->user_model->insert_disabled_seat($seat_id, $date_disabled, $currentDate);

            redirect('admin/dashboard'); // Redirect after success
        }

        $data['seat_id'] = $seat_id;
        $data['created_date'] = $currentDate;

        $this->load->view('disable_seat_views', $data);
    }

    public function enable_seats()
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/adminlogin');
        }

        $data['disabled_seats'] = $this->user_model->get_disabled_seats();
        $this->load->view("admin_enable_seats.php", $data);
    }

    public function enable_seat($id = null)
    {
        if (!$this->session->userdata('admin_logged_in')) {
            redirect('admin/adminlogin');
        }

        if ($id === null) {
            show_error('Seat ID is required.', 400);
        }

        $this->user_model->delete_disabled_seat($id);
        redirect('admin/enable_seats');
    }


    public function delete_masterlist_email()
    {
        $email_id = $this->input->post('email_id');
        if ($email_id) {
            $this->db->delete('tbl_library_masterlist', array('id' => $email_id)); // replace with your table
            $this->session->set_flashdata('success', 'Email deleted successfully.');
        } else {
            $this->session->set_flashdata('error', 'Invalid email ID.');
        }
        redirect('masteradmin/manage_masterlist');
    }


    //new updates 13/05
    public function urgent_reservation()
    {
        $this->load->view('admin_urgent_reservation.php');
    }

    public function urgent_selectseats()
    {
        $this->load->model('user_model');

        $date = $this->input->post('date');

        if ($date) {
            $this->session->set_userdata('urgent_reservation_date', $date);
        } else {
            $this->session->set_flashdata('error', 'Please select a date first.');
            redirect('admin/urgent_reservation_view');
            return;
        }

        // Get all seat assignments for this date
        //         $occupied_reservations = $this->user_model->get_all_seat_status_by_date_occupied($date);
        // $closed_reservations = $this->user_model->get_all_seat_status_by_date_closed($date);
        $na_reservations = $this->user_model->get_all_seat_status_by_date_librarian($date);

        // Initialize all to available by default (assume you have 100 seats, adjust as needed)
        $slot_display = array_fill(0, 100, 'available');

        foreach ($na_reservations as $row) {
            $index = $row->seat_id - 1;
            if (isset($slot_display[$index])) {
                $slot_display[$index] = 'not-available';
            }
        }
        //    foreach ($closed_reservations as $row) {
        //     $index = $row->seat_id - 1;
        //     if (isset($slot_display[$index])) {
        //         $slot_display[$index] = 'closed';
        //     }
        // }
        //    foreach ($occupied_reservations as $row) {
        //     $index = $row->seat_id - 1;
        //     if (isset($slot_display[$index])) {
        //         $slot_display[$index] = 'occupied';
        //     }
        // }
        // var_dump($seat_reservations);

        $data = [
            'selected_date' => $date,
            'slot_display'  => $slot_display,
            'current_date'  => date('Y-m-d H:i:s'),
        ];

        $this->load->view('admin_urgent_select_seats.php', $data);
    }

    public function submit_urgent_reservation()
    {
        $this->load->model('user_model');
        date_default_timezone_set('Asia/Manila');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $seat_ids = $this->input->post('seat_assigned');
            $date_disabled = $this->input->post('date_disabled');
            $created_date = date('Y-m-d H:i:s');

            if (!$seat_ids || !$date_disabled) {
                $this->session->set_flashdata('error', 'Missing seat selection or date.');
                redirect('admin/urgent_reservation');
                return;
            }

            $seat_ids_array = explode(',', $seat_ids);

            // Step 1: Disable selected seats
            foreach ($seat_ids_array as $seat_id) {
                $this->db->insert('tbl_library_assign_disabled', [
                    'seat_id'       => $seat_id,
                    'date_disabled' => $date_disabled,
                    'created_date'  => $created_date
                ]);
            }

            // Step 2: Get reservations for the selected seats and date
            $reservations = $this->user_model->get_reservations_by_date($date_disabled);
            $affected_users = [];

            foreach ($reservations as $res) {
                if (!in_array($res['seat_id'], $seat_ids_array)) continue;

                $slot_time = $this->user_model->get_slot_time($res['slot_id']);
                if (!$slot_time) continue;

                $end_time = strtotime($date_disabled . ' ' . $slot_time['end_time']);
                if (time() > $end_time) continue;

                $affected_users[] = [
                    'student_id' => $res['student_id'],
                    'seat_id'    => $res['seat_id'],
                    'slot_id'    => $res['slot_id'],
                    'status'     => $res['status']
                ];
            }

            // Step 3: Notify and Archive
            foreach ($affected_users as $user) {
                $message = $user['status'] == 'Closed'
                    ? "Sorry, looks like the seats you reserved for today have been disabled/cancelled by the Librarian. Thank you for understanding."
                    : "Sorry, the seat you occupied for today has been disabled by the Librarian. Please leave your seat as soon as possible. Thank you.";

                $this->user_model->add_notification($user['student_id'], $user['seat_id'], $message);
                $this->user_model->archive_reservation($user['student_id'], $user['seat_id'], $date_disabled);
            }

            $this->session->set_flashdata('success', 'Selected seats have been disabled and affected users were notified.');
            redirect('admin/dashboard');
        }
    }



    public function disable_all_seats_view()
    {
        $this->load->view('admin_disable_all_seats.php');
    }

        public function enable_all_seats_view()
    {
        $this->load->view('admin_enable_all_seats.php');
    }

    public function disable_all_seats()
    {
        $this->load->model('user_model');
        date_default_timezone_set('Asia/Manila');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $date_disabled = $this->input->post('date_disabled');
            $created_date = date('Y-m-d H:i:s');
            $created_date_specific = date('Y-m-d');
            // Step 1: Disable all seats
            $all_seat_ids = $this->user_model->get_all_seat_ids();

            //DELETE ALL RESERVE ON THAT DAY
            $this->user_model->remove_disabled_specific_date($created_date_specific);

            foreach ($all_seat_ids as $seat) {
                $this->db->insert('tbl_library_assign_disabled', [
                    'seat_id'       => $seat['id'],
                    'date_disabled' => $date_disabled,
                    'created_date'  => $created_date
                ]);
            }

            // Step 2: Get reservations for that date
            $reservations = $this->user_model->get_reservations_by_date($date_disabled);
            $affected_users = [];

            foreach ($reservations as $res) {
                // Safety check: only process seats that were disabled
                if (!in_array($res['seat_id'], array_column($all_seat_ids, 'id'))) continue;

                $slot_time = $this->user_model->get_slot_time($res['slot_id']);
                if (!$slot_time) continue;

                // Check if current time is before end time
                $end_time = strtotime($date_disabled . ' ' . $slot_time['end_time']);
                if (time() > $end_time) continue;

                $affected_users[] = [
                    'student_id' => $res['student_id'],
                    'seat_id'    => $res['seat_id'],
                    'slot_id'    => $res['slot_id'],
                    'status'     => $res['status']
                ];
            }

            // Step 3: Notify and Archive
            foreach ($affected_users as $user) {
                // Create message based on status
                $message = '';
                if ($user['status'] == 'Closed') {
                    $message = "Sorry, looks like the seats you reserved for today have been disabled/cancelled by the Librarian. Thank you for understanding.";
                } elseif ($user['status'] == 'Occupied') {
                    $message = "Sorry, the seat you occupied for today has been disabled by the Librarian. Please leave your seat as soon as possible. Thank you.";
                }

                // Add notification
                $this->user_model->add_notification($user['student_id'], $user['seat_id'], $message);

                // Archive the reservation
                $this->user_model->archive_reservation($user['student_id'], $user['seat_id'], $date_disabled);
            }

            $this->session->set_flashdata('success', 'All seats have been disabled. Affected users were notified.');
            redirect('admin/dashboard');
        } else {
            $data['created_date'] = date('Y-m-d H:i:s');
            $this->load->view('admin_disable_all_seats', $data);
        }
    }


    public function enable_all_seats()
    {
        $this->load->model('user_model');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $date_disabled = $this->input->post('date_disabled');
            var_dump($date_disabled);
            $this->user_model->remove_disabled_specific_date($date_disabled);

            // foreach ($all_seat_ids as $seat) {
            //     $this->db->insert('tbl_library_assign_disabled', [
            //         'seat_id'       => $seat['id'],
            //         'date_disabled' => $date_disabled,
            //         'created_date'  => $created_date
            //     ]);
            // }

          
            $this->session->set_flashdata('success', 'All seats have been enabled.');
            redirect('admin/dashboard');
        } else {
            // $data['created_date'] = date('Y-m-d H:i:s');
            // $this->load->view('admin_disable_all_seats', $data);
        }
    }
}
