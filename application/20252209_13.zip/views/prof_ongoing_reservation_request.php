<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        html,
        body {
            height: 100%;
            margin: 0;
        }

        .wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .content {
            flex: 1;
        }

        .header {
            background-color: #880007;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .logo {
            height: 60px;
            width: auto;
        }

        .user-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
        }


        .footer {
            background-color: #880007;
            color: white;
            text-align: center;
            padding: 10px;
        }

        .footer-logo {
            height: 100px;
            margin-bottom: 5px;
        }

        .footer-text {
            font-size: 12px;
            margin: 5px 0;
        }

        .footer-link {
            color: white;
            text-decoration: underline;
            font-size: 12px;
        }

        .list-group-item.active {
            background-color: #e0ff00 !important;
            color: black !important;
        }

        .reservation-entry {
            background-color: #f8f9fa;
            padding: 6px 12px;
            border-radius: 6px;
            margin-bottom: 6px;
            font-size: 0.9rem;
            text-decoration: none;
            color: inherit;
            transition: background-color 0.2s ease;
        }

        /*
        .reservation-entry:hover {
            background-color: #e2e6ea;
            cursor: pointer;
        }
            */
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="header">
            <img src="<?= base_url('assets_systems/lpulogo.png') ?>" alt="LPU Logo" class="logo">
            <span>Reservation Request</span>
            <div class="dropdown">
                <img src="<?= base_url('assets_systems/usericon.png') ?>" alt="User Icon" class="user-icon dropdown-toggle" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item text-danger" id="logoutBtn">Log Out</a></li>
                </ul>
            </div>

            <!-- Logout Confirmation Modal -->
            <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body text-center">
                            <p class="text-dark fw-bold">Are you sure you want to log out?</p>
                            <button type="button" class="btn btn-danger" id="confirmLogout">Yes</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <main class="content">
            <div class="mt-3 ms-3">
                <a href="<?= base_url('index/homepage') ?>" class="btn btn-outline-dark btn-sm">
                    ← Home
                </a>
            </div>

            <div class="container-fluid mt-4">
                <div class="row">
                    <!-- Sidebar -->
                    <div class="col-md-3 col-lg-2">
                        <div class="list-group">
                            <a href="<?= base_url('index/reservationrequest') ?>" class="list-group-item list-group-item-action">Reservation Request</a>
                            <a href="<?= base_url('index/ongoing_request') ?>" class="list-group-item list-group-item-action active bg-warning border-0 fw-bold text-dark">Ongoing Reservation</a>
                        </div>
                    </div>

                    <div class="col-md-9 col-lg-10">
                        <?php if (!empty($ongoing_requests)): ?>
                            <?php foreach ($ongoing_requests as $request): ?>
                                <a href="<?php echo base_url('index/process_request_ongoing/' . $request->id); ?>"
                                    class="reservation-entry d-flex justify-content-between align-items-center mb-2 p-2 border rounded">
                                    <span>📅 Requested Date: <?= date('m/d/Y', strtotime($request->date)); ?></span>
                                    <span><?= htmlspecialchars($request->prof_name); ?></span>
                                    <span><?= htmlspecialchars($request->prof_id); ?></span>
                                    <form method="post" action="<?= site_url('admin/terminated_reservation/' . $request->id); ?>">
                                        <button class="btn btn-sm btn-danger" type="submit">Cancel</button>
                                    </form>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No ongoing professor reservations.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>

        <footer class="footer mt-3">
            <img src="<?= base_url('assets_systems/RS LOGO.png') ?>" alt="LPU Logo" class="footer-logo">
            <p class="footer-text">
                Copyright © Lyceum of the Philippines University - Cavite 2024.<br>
                All Rights Reserved. <a href="<?= base_url('index/dataprivacypolicy') ?>" class="footer-link">Privacy Policy</a>
            </p>
            <a href="https://www.cavite.lpu.edu.ph" target="_blank" class="footer-link">www.cavite.lpu.edu.ph</a>
        </footer>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>


    <script>
        document.addEventListener("DOMContentLoaded", function() {

            setTimeout(function() {
                location.reload();
            }, 60000); // 10000ms = 10 seconds


            //UserIconDropdown
            let userDropdown = document.getElementById("userDropdown");
            let dropdownMenu = userDropdown.nextElementSibling;

            document.addEventListener("mouseleave", function(event) {
                if (!userDropdown.contains(event.relatedTarget) && !dropdownMenu.contains(event.relatedTarget)) {
                    dropdownMenu.classList.remove("show");
                    userDropdown.setAttribute("aria-expanded", "false");
                }
            });

            document.getElementById("logoutBtn").addEventListener("click", function() {
                let logoutModal = new bootstrap.Modal(document.getElementById("logoutModal"));
                logoutModal.show();
            });

            document.getElementById('confirmLogout').addEventListener('click', function() {
                window.location.href = "<?= base_url('index/logout') ?>";
            });


        });
    </script>
</body>

</html>